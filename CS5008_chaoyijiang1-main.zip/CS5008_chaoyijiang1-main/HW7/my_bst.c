// Chaoyi Jiang
// Mar 29 2023
//
// Include our header file for our my_bst.c
#include "my_bst.h"

// Include any other libraries needed
#include <stdio.h>
#include <stdlib.h>

// Creates a BST
// Returns a pointer to a newly created BST.
// The BST should be initialized with data on the heap.
// The BST fields should also be initialized to default values(i.e. size=0).
bst_t* bst_create(){
    // Modify the body of this function as needed.
    bst_t* newTree = (bst_t*)malloc(sizeof(bst_t));
    newTree->root = NULL;
    newTree->size = 0;
    return newTree;
}

// BST Empty
// Check if the BST is empty
// Returns 1 if true (The BST is completely empty)
// Returns 0 if false (the BST has at least one element)
int bst_empty(bst_t* t){
    return (t->root == NULL);
}

// Adds a new node containg item to the BST
// The item is added in the correct position in the BST.
//  - If the data is less than or equal to the current node we traverse left
//  - otherwise we traverse right.
// The bst_function returns '1' upon success
//  - bst_add should increment the 'size' of our BST.
// Returns a -1 if the operation fails.
//      (i.e. the memory allocation for a new node failed).
// Your implementation should should run in O(log(n)) time.
//  - A recursive imlementation is suggested.
int bst_add(bst_t* t, int item){
    bstnode_t* newNode = (bstnode_t*)malloc(sizeof(bstnode_t));
    newNode->data = item;
    newNode->leftChild = NULL;
    newNode->rightChild = NULL;
    if(t->root == NULL){
        t->root = newNode;
        t->size++;
        return 1;
    }else{
        bstnode_t* current = t->root;
        bstnode_t* parent;
        while(1){
            parent = current;
            if(item < parent->data){
                current = current->leftChild;
                if(current == NULL){
                    parent->leftChild = newNode;
                    t->size++;
                    return 1;
                }
            }else{
                current = current->rightChild;
                if(current == NULL){
                    parent->rightChild = newNode;
                    t->size++;
                    return 1;
                }
            }
        }
    }
}

// Print the items in the BST in the specified order (in-order, pre-order, or post-order)
void print_in_order(bstnode_t* node){
    if(node != NULL){
        print_in_order(node->leftChild);
        printf("%d ", node->data);
        print_in_order(node->rightChild);
    }
}

void print_pre_order(bstnode_t* node){
    if(node != NULL){
        printf("%d ", node->data);
        print_pre_order(node->leftChild);
        print_pre_order(node->rightChild);
    }
}

void print_post_order(bstnode_t* node){
    if(node != NULL){
        print_post_order(node->leftChild);
        print_post_order(node->rightChild);
        printf("%d ", node->data);
    } 
}

// Prints the tree in ascending order if order = 0, otherwise prints in descending order.
// A BST that is NULL should print "(NULL)"
// It should run in O(n) time.
void bst_print(bst_t *t, int order){
    if(t->root != NULL){
        if(order == 0){
            print_in_order(t->root);
        }else if(order == 1){
            print_pre_order(t->root);
        }else if(order == 2){
            print_post_order(t->root);
        }else{
            printf("Invalid order specified.\n");
        }
    }else{
        printf("BST is empty.\n");
    }
}

// Returns the sum of all the nodes in the bst. 
// A BST that is NULL exits the program.
// It should run in O(n) time.
int bst_sum(bst_t *t){
    int sum = 0;
    if(t->root == NULL){
        return sum;
    }
    else{
        bstnode_t* current = t->root;
        bstnode_t* stack[t->size];
        int top = -1;
        while(current != NULL || top != -1){
            while(current != NULL){
                stack[++top] = current;
                current = current->leftChild;
            }
            current = stack[top--];
            sum += current->data;
            current = current->rightChild;
        }
        return sum;
    }
}

// Returns 1 if value is found in the tree, 0 otherwise. 
// For NULL tree -- exit the program. 
// It should run in O(log(n)) time.
int bst_find(bst_t * t, int value){
    if(t->root == NULL){
        return 0;
    }
    else{
        bstnode_t* current = t->root;
        while(current != NULL){
            if(current->data == value){
                return 1;
            }
            else if(current->data > value){
                current = current->leftChild;
            }
            else{
                current = current->rightChild;
            }
        }
        return 0;
    }
}

// Returns the size of the BST
// A BST that is NULL exits the program.
// (i.e. A NULL BST cannot return the size)
unsigned int bst_size(bst_t* t){
    return t->size;
}

// Free BST
// Removes a BST and ALL of its elements from memory.
// This should be called before the proram terminates.
void bst_free(bst_t* t){
    if(t->root != NULL){
        bstnode_t* current = t->root;
        bstnode_t* parent = NULL;
        while(current != NULL){
            if(current->leftChild != NULL){
                bstnode_t* temp = current->leftChild;
                current->leftChild = parent;
                parent = current;
                current = temp;
            }
            else if(current->rightChild != NULL){
                bstnode_t* temp = current->rightChild;
                current->rightChild = parent;
                parent = current;
                current = temp;
            }
            else{
                free(current);
                current = parent;
                if(current != NULL){
                    if(current->leftChild != NULL){
                        current->leftChild->rightChild = NULL;
                        parent = current->leftChild;
                        current->leftChild = NULL;
                    }
                    else if(current->rightChild != NULL){
                        current->rightChild->leftChild = NULL;
                        parent = current->rightChild;
                        current->rightChild = NULL;
                    }
                    else{
                        parent = NULL;
                    }
                }
            }
        }
    }
    free(t);
}

