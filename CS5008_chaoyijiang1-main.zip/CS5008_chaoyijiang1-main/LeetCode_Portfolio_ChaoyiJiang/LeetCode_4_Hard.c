// Your Name Chaoyi Jiang
// The Date Apr 23 2023 
// Final Interview LeetCode04 https://leetcode.com/problems/median-of-two-sorted-arrays/description/

double findMedianSortedArrays(int* nums1, int nums1Size, int* nums2, int nums2Size) {
    const int totalLength = nums1Size + nums2Size;
    int index1 = 0, index2 = 0;
    int merged[totalLength];
    for (int i = 0; i < totalLength; i++) {
        if (index1 >= nums1Size) {
            merged[i] = nums2[index2++];
        } else if (index2 >= nums2Size) {
            merged[i] = nums1[index1++];
        } else if (nums1[index1] < nums2[index2]) {
            merged[i] = nums1[index1++];
        } else {
            merged[i] = nums2[index2++];
        }
    }
    if (totalLength % 2 == 1) {
        return merged[totalLength / 2];
    } else {
        return (merged[totalLength / 2] + merged[totalLength / 2 - 1]) / 2.0;
    }
}