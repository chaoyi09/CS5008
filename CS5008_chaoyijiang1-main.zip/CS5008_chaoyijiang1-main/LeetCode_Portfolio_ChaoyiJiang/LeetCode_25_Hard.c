// Your Name Chaoyi Jiang
// The Date Apr 24 2023 
// LeetCodeHard3 https://leetcode.com/problems/reverse-nodes-in-k-group/description/?q=solution+in+c&orderBy=most_relevant

struct ListNode* reverseKGroup(struct ListNode* head, int k) {
    int i;
    struct ListNode d, *p, *q, *r, *s, *t, *u;
    d.next = head;
    p = &d;
    while (1) {
        q = p->next;
        s = NULL;

        /* Check that there are enough remaining nodes */
        for (r = q, i = 1; i <= k; ++i) {
            if (r == NULL) {
                return d.next;
            }
            r = r->next;
        }

        /* Reverse the current group of nodes */
        for (r = q, i = 1; i <= k; ++i) {
            if (i == k) {
                u = r->next;
            }
            t = r;
            if (i < k) {
                r = r->next;
            }
            t->next = s;
            s = t;
        }

        /* Reconnect the reversed group of nodes to the rest of the list */
        q->next = u;
        p->next = t;
        p = q;
    }
}
