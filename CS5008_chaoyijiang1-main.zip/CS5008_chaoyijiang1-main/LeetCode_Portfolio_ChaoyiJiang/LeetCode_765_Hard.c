// Your Name Chaoyi Jiang
// The Date Apr 24 2023 
// LeetCodeHard3 https://leetcode.com/problems/couples-holding-hands/description/

int minSwapsCouples(int* row, int rowSize){
    int positions[60];
    int numSwaps = 0;
    int partner, partnerPos, temp;
    
    /* Build look-up table of positions. */
    for (int i = 0; i < rowSize; i++)
        positions[row[i]] = i;
    
    for (int i = 0; i < rowSize; ++i) {
        partner = row[i] ^ 1;
        
        /* If adjacent element isn't adjacent value... */
        if (partner != row[++i]) {
            /* ...swap cached position of values... */
            partnerPos = positions[partner];
            positions[row[i]] = partnerPos;
            positions[partner] = i;
            
            /* ...and swap values in array. */
            temp = row[partnerPos];
            row[partnerPos] = row[i];
            row[i] = temp;
            
            ++numSwaps;
        }
    }
    
    return numSwaps;
}
