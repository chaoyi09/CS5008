// Your Name Chaoyi Jiang
// The Date Apr 24 2023 
// LeetCodeMedium2 https://leetcode.com/problems/sort-list/

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     struct ListNode *next;
 * };
 */

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}


struct ListNode* sortList(struct ListNode* head) {
    struct ListNode* temp = head;
    int count = 0;
    int index = 0;

    if (head == NULL) {
        return head;
    }

    while (temp) {
        temp = temp->next;
        count++;
    }

    int *newArr = (int*)malloc(sizeof(int) * count);

    temp = head;
    while (temp) {
        newArr[index] = temp->val;
        temp = temp->next;
        index++;
    }

    qsort(newArr, count, sizeof(int), cmpfunc);

    temp = head;
    index = 0;

    while (temp) {
        temp->val = newArr[index];
        temp = temp->next;
        index++;
    }

    free(newArr);

    return head;
}
