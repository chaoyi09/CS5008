// Your Name Chaoyi Jiang
// The Date Apr 24 2023 
// LeetCode01Hard https://leetcode.com/problems/edit-distance/

#define MIN(X,Y) ((X > Y) ? Y : X)

int minDistance(char * word1, char * word2){
    size_t length1 = strlen(word1);
    size_t length2 = strlen(word2);
    int *row = malloc(sizeof(int) * (length1 + 1));
    int last;
    int temp;
    for(int i = 0; i <= length1;++i)
        row[i] = i;
    for(int i = 1;i <= length2;++i)
    {
        last = row[0];
        row[0] = i;
        for(int j = 1;j <= length1;++j)
        {
            temp = row[j];
            if(word1[j - 1] == word2[i - 1])
                row[j] = last;
            else
                row[j] = MIN(MIN(row[j],row[j - 1]),last) + 1;
            last = temp;
        }
    }
    last = row[length1];
    free(row);
    return last;
}
