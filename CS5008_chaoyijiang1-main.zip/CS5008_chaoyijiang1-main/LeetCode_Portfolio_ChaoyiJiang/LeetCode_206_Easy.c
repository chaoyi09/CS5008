// Your Name Chaoyi Jiang
// The Date Apr 24 2023 
// LeetCodeMedium2 https://leetcode.com/problems/reverse-linked-list/description/


struct ListNode* reverseList(struct ListNode* head) {
    // Base case: linked list is empty, has a single element, or head points to the tail
    if (head == NULL || head->next == NULL) {
        return head;
    }
    // Recursive case
    struct ListNode* nextNode = head->next;
    struct ListNode* newHead = reverseList(head->next);
    nextNode->next = head;
    head->next = NULL;
    return newHead;
}
