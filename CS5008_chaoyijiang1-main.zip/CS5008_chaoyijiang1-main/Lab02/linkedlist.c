// Modify this file
// compile with: gcc linkedlist.c -o linkedlist
// TODO: Chaoyi Jiang
// TODO: Feb 01 2023
// Lab02 CS5008 Spring 2023

#include <stdio.h>
#include <stdlib.h> // contains the functions free/malloc

// TODO: 
typedef struct node{
	int year;
	int wins;
	struct node *next;
} node_t;



// TODO: Write your functions here
// There should be 1.) create_list 2.) print_list 3.) free_list
// You may create as many helper functions as you like.

node_t *create_list(int year[], int wins[], int size){
	node_t *head = NULL;
	node_t *current = NULL;
	for(int i=0; i<size; i++){
		node_t *new_node = (node_t*)malloc(sizeof(node_t));
		new_node->year = year[i];
		new_node->wins = wins[i];
		new_node->next = NULL;
		if(head == NULL){
			head = new_node;
			current = new_node;
		}else{
			current->next = new_node;
			current = new_node;
		}
	}
	return head;
}

void print_list(node_t *head){
	node_t *current = head;
	while(current != NULL){
		printf("%d, %d wins\n", current->year, current->wins);
		current = current->next;
	}
}

void free_list(node_t *head){
	node_t *current = head;
	while(current != NULL){
		node_t *next = current->next;
		free(current);
		current = next;
	}
}


int main(){
	int years[] = {2018, 2017, 2016, 2015, 2014};
	int wins[] = {108, 93, 93, 78, 71};
	int size = sizeof(years)/sizeof(years[0]);
	node_t *head = create_list(years, wins, size);
	print_list(head);
	free_list(head);
	return 0;
}
