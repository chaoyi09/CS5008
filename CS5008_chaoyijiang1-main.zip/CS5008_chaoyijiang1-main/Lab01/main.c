// chaoyi jiang
// Jan 27 2023
// Labo1_First C Program

#include <stdio.h>


double power(double base, double n) {
	double result = 1;
	for (int i = 0; i < n; i++) {
		result *= base;
	}

	return result;

}


int main() {
	for (int i = 1; i <= 10; i++) {
		printf("%.01f^%.01f = %1f\n", 2.0, (double)i, power(2.0, (double)i));

	}

	return 0;

}
	 

