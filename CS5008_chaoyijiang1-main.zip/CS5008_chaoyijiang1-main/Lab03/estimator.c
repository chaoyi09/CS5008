// Chaoyi Jiang
// Feb 19 2023
// CS5008 Lab03
//
// Implement your cycle count tool here.

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: estimator filename.s\n");
        return 1;
    }
    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Unable to open file: %s\n", argv[1]);
        return 1;
    }

    char line[100];
    int add_count = 0, sub_count = 0, mul_count = 0, div_count = 0, mov_count = 0, lea_count = 0, push_count = 0, pop_count = 0, ret_count = 0;

    while (fgets(line, sizeof(line), file)) {
        // Count the ADD instructions
        if (strstr(line, "ADD") || strstr(line, "add")) {
            add_count++;
        }
        // Count the SUB instructions
        else if (strstr(line, "SUB") || strstr(line, "sub")) {
            sub_count++;
        }
        // Count the MUL instructions
        else if (strstr(line, "MUL") || strstr(line, "mul") || strstr(line, "IMUL") || strstr(line, "imul")) {
            mul_count++;
        }
        // Count the DIV instructions
        else if (strstr(line, "DIV") || strstr(line, "div") || strstr(line, "IDIV") || strstr(line, "idiv")) {
            div_count++;
        }
        // Count the MOV instructions
        else if (strstr(line, "MOV") || strstr(line, "mov")) {
            mov_count++;
        }
        // Count the LEA instructions
        else if (strstr(line, "LEA") || strstr(line, "lea")) {
            lea_count++;
        }
        // Count the PUSH instructions
        else if (strstr(line, "PUSH") || strstr(line, "push")) {
            push_count++;
        }
        // Count the POP instructions
        else if (strstr(line, "POP") || strstr(line, "pop")) {
            pop_count++;
        }
        // Count the RET instructions
        else if (strstr(line, "RET") || strstr(line, "ret")) {
            ret_count++;
        }
    }

    int total_cycles = add_count + sub_count + (3 * mul_count) + (24 * div_count) + mov_count + (3 * lea_count) + push_count + pop_count + ret_count;
    printf("ADD %d\n", add_count);
    printf("SUB %d\n", sub_count);
    printf("MUL %d\n", mul_count);
    printf("DIV %d\n", div_count);
    printf("MOV %d\n", mov_count);
    printf("LEA %d\n", lea_count);
    printf("PUSH %d\n", push_count);
    printf("POP %d\n", pop_count);
    printf("RET %d\n", ret_count);
    printf("Total Instructions = %d\n", add_count + sub_count + mul_count + div_count + mov_count + lea_count + push_count + pop_count + ret_count);
    printf("Total Cycles = %d\n", total_cycles);

    fclose(file);
    return 0;
}
