Lab00 Questions - Feb 02, 2023

As part of the Lab00 exercise, please complete the answers to the 
questions below:

1)  What is your name?

Chaoyi Jiang

2)  What is your khoury username?

chaoyijiang1

3)  What is your primary email address?  The address that ends 
@northeastern.edu.

jiang.chao@northeastern.edu

4)  Approximately how long did it take for you to complete this lab in 
minutes?


20days

