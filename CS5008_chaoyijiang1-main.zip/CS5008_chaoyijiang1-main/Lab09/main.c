// Chaoyi Jiang
// Mar 29 2023
//
// Compile this assignment with: gcc -Wall main.c my_dll.c myqueue.c my_graph.c myown.c -o main
//
// Include parts of the C Standard Library
// These have been written by some other really
// smart engineers.
#include <stdio.h>  // For IO operations
#include <stdlib.h> // for malloc/free

// Our library that we have written.
// Also, by a really smart engineer!

#include "my_graph.h"


int main(int argc, const char * argv[]) {

    graph_t * graph = create_graph();

    graph_add_node(graph, 1);
    graph_add_node(graph, 1);
    graph_add_node(graph, 2);

    printf("total nodes: 2==%d\n", graph_num_nodes(graph));

    return 0;
}
