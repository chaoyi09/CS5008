#ifndef MYQUEUE_H
#define MYQUEUE_H

#include "my_graph.h"

// The main data structure for the queue
typedef struct pq_node {
    graph_node_t *data;
    int cost;
    struct pq_node *prev;
    struct pq_node *next;
} pq_node_t;

typedef struct {
    pq_node_t *head;
    pq_node_t *tail;
} my_pq_t;

// Create an empty priority queue
my_pq_t *create_pq()
{
    my_pq_t *pq = malloc(sizeof(my_pq_t));
    pq->head = NULL;
    pq->tail = NULL;
    return pq;
}

// Enqueue a node with the given cost
void pq_enqueue(my_pq_t *pq, graph_node_t *node, int cost)
{
    pq_node_t *new_node = malloc(sizeof(pq_node_t));
    new_node->data = node;
    new_node->cost = cost;
    new_node->prev = NULL;
    new_node->next = NULL;

    if (pq->head == NULL) {
        pq->head = new_node;
        pq->tail = new_node;
        return;
    }

    pq_node_t *curr = pq->head;
    while (curr != NULL && curr->cost < cost) {
        curr = curr->next;
    }

    if (curr == pq->head) {
        new_node->next = pq->head;
        pq->head->prev = new_node;
        pq->head = new_node;
    } else if (curr == NULL) {
        new_node->prev = pq->tail;
        pq->tail->next = new_node;
        pq->tail = new_node;
    } else {
        new_node->prev = curr->prev;
        curr->prev->next = new_node;
        new_node->next = curr;
        curr->prev = new_node;
    }
}

// Dequeue the node with the minimum cost
graph_node_t *pq_dequeue(my_pq_t *pq)
{
    if (pq->head == NULL) {
        return NULL;
    }

    pq_node_t *min_node = pq->head;
    pq->head = pq->head->next;

    if (pq->head != NULL) {
        pq->head->prev = NULL;
    } else {
        pq->tail = NULL;
    }

    graph_node_t *min_data = min_node->data;
    free(min_node);

    return min_data;
}

// Check if the priority queue is empty
int pq_is_empty(my_pq_t *pq)
{
    return pq->head == NULL;
}

void free_queue(my_pq_t* pq){
	// TODO: Implement me!
	free(q->data);
    free(q);
}

#endif
