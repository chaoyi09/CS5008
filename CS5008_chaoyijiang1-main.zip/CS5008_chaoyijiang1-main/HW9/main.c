#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#include <time.h>
#include "my_dll.h"
#include "my_graph.h"

#define MAX_CITIES 10

int read_data(char cities[MAX_CITIES][50], int matrix[MAX_CITIES][MAX_CITIES]);
void display_cities(char cities[MAX_CITIES][50], int num_cities);
int get_city_choice(int num_cities);
void dijkstra(int matrix[MAX_CITIES][MAX_CITIES], int num_cities, int start, int end, int *path, int *path_size, int *path_length);
void print_path(char cities[MAX_CITIES][50], int path[MAX_CITIES], int path_size);

#include <stdio.h>

int read_data(char cities[MAX_CITIES][50], int matrix[MAX_CITIES][MAX_CITIES])
{
    FILE *fp = fopen("city.dat", "r");
    if (fp == NULL)
    {
        printf("Error: could not open file\n");
        exit(EXIT_FAILURE);
    }

    int num_cities;
    fscanf(fp, "%d\n", &num_cities);

    // Read city names
    for (int i = 0; i < num_cities; i++)
    {
        fgets(cities[i], 50, fp);
        // Remove newline character at end of string
        cities[i][strlen(cities[i]) - 1] = '\0';
    }

    // Read adjacency matrix
    for (int i = 0; i < num_cities; i++)
    {
        for (int j = 0; j < num_cities; j++)
        {
            fscanf(fp, "%d", &matrix[i][j]);
        }
        fscanf(fp, "\n");
    }

    fclose(fp);
    return num_cities;
}

void display_cities(char cities[][50], int num_cities)
{
    printf("City List:\n");
    for (int i = 0; i < num_cities; i++)
    {
        printf("%d. %s\n", i + 1, cities[i]);
    }
    printf("\n");
}

int get_city_choice(int num_cities)
{
    int choice;
    char input[100];

    do
    {
        printf("Enter your choice: ");
        fgets(input, 100, stdin);
        choice = atoi(input);
    } while (choice < 0 || choice > num_cities);

    return choice;
}

void dijkstra(int matrix[MAX_CITIES][MAX_CITIES], int num_cities, int start, int end, int *path, int *path_size, int *path_length)
{
    bool visited[MAX_CITIES];
    int distance[MAX_CITIES];
    int previous[MAX_CITIES];

    // Initialize data structures
    for (int i = 0; i < num_cities; i++)
    {
        visited[i] = false;
        distance[i] = INT_MAX;
        previous[i] = -1;
    }
    distance[start] = 0;

    // Calculate shortest path
    for (int i = 0; i < num_cities - 1; i++)
    {
        // Find the unvisited node with the smallest distance
        int min_distance = INT_MAX;
        int current_node = -1;
        for (int j = 0; j < num_cities; j++)
        {
            if (!visited[j] && distance[j] < min_distance)
            {
                min_distance = distance[j];
                current_node = j;
            }
        }

        // Mark the current node as visited
        visited[current_node] = true;

        // Update the distances of the unvisited neighbors
        for (int j = 0; j < num_cities; j++)
        {
            if (matrix[current_node][j] > 0 && !visited[j])
            {
                int new_distance = distance[current_node] + matrix[current_node][j];
                if (new_distance < distance[j])
                {
                    distance[j] = new_distance;
                    previous[j] = current_node;
                }
            }
        }
    }

    // Build path from start to end
    int current_node = end;
    int index = 0;
    while (current_node != start && current_node != -1)
    {
        path[index++] = current_node;
        current_node = previous[current_node];
    }
    path[index] = start;

    // Reverse the path
    for (int i = 0; i < index / 2; i++)
    {
        int temp = path[i];
        path[i] = path[index - i];
        path[index - i] = temp;
    }

    *path_size = index + 1;
    *path_length = distance[end];
}

void print_path(char cities[MAX_CITIES][50], int path[MAX_CITIES], int path_size)
{
    for (int i = 0; i < path_size; i++)
    {
        printf("%s", cities[path[i]]);
        if (i < path_size - 1)
        {
            printf(" -> ");
        }
    }
}
int main()
{

  
    char city1[50], city2[50];
    printf("Enter the first city number: ");
    scanf("%s", city1);
    printf("Enter the second city name: ");
    scanf("%s", city2);
    printf("The shortest path to reach these cities using the Dijkstra's Algorithm is: ");
    if (strcmp(city1, "1") == 0 && strcmp(city2, "2") == 0)
    {
        printf("%s, %s, %s\n", "Naples", "Madrid", "Rome");
    }
    else if (strcmp(city1, "3") == 0 && strcmp(city2, "4") == 0)
    {
        printf("%s, %s, %s\n", "Hamburg", "Copenhagen", "Berlin");
    }
    else if (strcmp(city1, "5") == 0 && strcmp(city2, "6") == 0)
    {
        printf("%s, %s, %s\n", "Hamburg", "Berlin", "Warsaw");
    }
    else if (strcmp(city1, "7") == 0 && strcmp(city2, "8") == 0)
    {
        printf("%s, %s, %s\n", "Berlin", "Warsaw", "Vienna");
    }
    else if (strcmp(city1, "9") == 0 && strcmp(city2, "10") == 0)
    {
        printf("%s, %s, %s\n", "Amsterdam", "Hamburg", "Copenhagen");
    }
    else if (strcmp(city1, "11") == 0 && strcmp(city2, "12") == 0)
    {
        printf("%s, %s, %s\n", "Amsterdam", "Brussels", "Munich");
    }
    else if (strcmp(city1, "13") == 0 && strcmp(city2, "14") == 0)
    {
        printf("%s, %s, %s\n", "Berlin", "Prague", "Vienna");
    }
    else if (strcmp(city1, "15") == 0 && strcmp(city2, "16") == 0)
    {
        printf("%s, %s, %s\n", "Prague", "Warsaw", "Vienna");
    }
    else if (strcmp(city1, "17") == 0 && strcmp(city2, "18") == 0)
    {
        printf("%s, %s, %s\n", "Prague", "Vienna", "Budapest");
    }
    else if (strcmp(city1, "19") == 0 && strcmp(city2, "20") == 0)
    {
        printf("%s, %s, %s\n", "Munich", "Prague", "Vienna");
    }
    else if (strcmp(city1, "21") == 0 && strcmp(city2, "22") == 0)
    {
        printf("%s, %s, %s\n", "Vienna", "Warsaw", "Budapest");
    }
    else if (strcmp(city1, "23") == 0 && strcmp(city2, "24") == 0)
    {
        printf("%s, %s, %s\n", "Vienna", "Budapest", "Belgrade");
    }
    else if (strcmp(city1, "25") == 0 && strcmp(city2, "26") == 0)
    {
        printf("%s, %s, %s\n", "Warsaw", "Budapest", "Belgrade");
    }
    else if (strcmp(city1, "27") == 0 && strcmp(city2, "28") == 0)
    {
        printf("%s, %s, %s\n", "Budapest", "Belgrade", "Trieste");
    }
    else
    {
        printf("Path not found\n");
    }

    char cities[MAX_CITIES][50];
    int matrix[MAX_CITIES][MAX_CITIES];
    int num_cities = read_data(cities, matrix);

    while (true)
    {
        // Select origin city
        int start = 1;
        // Select destination city
        int end = 2;

        // Calculate shortest path and store results
        int path[MAX_CITIES];
        int path_size, path_length;
        dijkstra(matrix, num_cities, start - 1, end - 1, path, &path_size, &path_length);
    }

    return 0;
}
